#include<bits/stdc++.h>
using namespace std;
int main()
{
    string x,y;
    cin>>x>>y;
    int k=y.find(x);
    cout<<k;
    if(k>=0){cout<<"YES";}else{cout<<"NO";}

}
