#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin>>s;
    int k;
    cin>>k;
    string b;
    cin>>b;
    s.insert(k,b);
    cout<<s;
}
