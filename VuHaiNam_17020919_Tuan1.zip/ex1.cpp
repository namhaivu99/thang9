#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    getline(cin,s);
    int dem=s.length();
    for(int i=dem-1;i>=0;i--)
    {
        cout<<s[i];
    }

}
